-- Module-2 Assignment

-- 1. Create a customer table which comprises of these columns – ‘customer_id’, ‘first_name’,
-- ‘last_name’, ‘email’, ‘address’, ‘city’,’state’,’zip’

CREATE TABLE customer (
  customer_id INT PRIMARY KEY,
  first_name VARCHAR(50),
  last_name VARCHAR(50),
  email VARCHAR(100),
  address VARCHAR(100),
  city VARCHAR(50),
  state VARCHAR(50),
  zip VARCHAR(10)
);

-- 2. Insert 5 new records into the table

INSERT INTO customer (customer_id, first_name, last_name, email, address, city, state, zip)
VALUES
  (1, 'John', 'Doe', 'john@example.com', '123 Main St', 'San Jose', 'CA', '95123'),
  (2, 'Jane', 'Smith', 'jane@example.com', '456 Elm St', 'San Francisco', 'CA', '94101'),
  (3, 'George', 'Washington', 'george@example.com', '789 Oak St', 'San Jose', 'CA', '95123'),
  (4, 'Grace', 'Kelly', 'grace@example.com', '321 Pine St', 'Los Angeles', 'CA', '90001'),
  (5, 'Gabriel', 'Garcia', 'gabriel@example.com', '987 Maple St', 'San Jose', 'CA', '95123');


-- 3. Select only the ‘first_name’ & ‘last_name’ columns from the customer table

SELECT first_name, last_name
FROM customer;

-- 4. Select those records where ‘first_name’ starts with “G” and city is ‘San Jose’

SELECT *
FROM customer
WHERE first_name LIKE 'G%' AND city = 'San Jose';


-- Module-3 Assignment

-- 1. Create an ‘Orders’ table comprises of columns – ‘order_id’, ‘order_date’, ‘amount’,‘customer_id’

CREATE TABLE Orders (
  order_id INT PRIMARY KEY,
  order_date DATE,
  amount DECIMAL(10, 2),
  customer_id INT
);


-- 2. Make an inner join on ‘Customer’ & ‘Order’ tables on the ‘customer_id’ column 

SELECT * 
FROM customer
INNER JOIN Orders ON customer.customer_id = Orders.customer_id;

-- 3. Make left and right joins on ‘Customer’ & ‘Order’ tables on the ‘customer_id’ column

SELECT *
FROM customer
LEFT JOIN Orders ON customer.customer_id = Orders.customer_id;

SELECT *
FROM customer
RIGHT JOIN Orders ON customer.customer_id = Orders.customer_id;

-- 4. Update the ‘Orders’ table, set the amount to be 100 where ‘customer_id’ is 3

UPDATE Orders
SET amount = 100
WHERE customer_id = 3;


