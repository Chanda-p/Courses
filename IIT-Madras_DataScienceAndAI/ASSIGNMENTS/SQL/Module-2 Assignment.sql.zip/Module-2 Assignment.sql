-- 1. Create a customer table WITH – ‘customer_id’, ‘first_name’,‘last_name’, ‘email’, ‘address’, ‘city’,’state’,’zip’

CREATE TABLE customers (
  customer_id INTEGER PRIMARY KEY,
  first_name VARCHAR(50) NOT NULL,
  last_name VARCHAR(50) NOT NULL,
  email VARCHAR(50),
  address VARCHAR (100),
  city VARCHAR(20),
  state VARCHAR (20),
  zip VARCHAR(10)
);

-- 2. Insert 5 new records into the table

INSERT INTO customers (customer_id, first_name, last_name, email, address, city, state, zip)
VALUES
  (1, 'John', 'Doe', 'john@example.com', '123 Main St', 'San Jose', 'CA', '95123'),
  (2, 'Jane', 'Smith', 'jane@example.com', '456 Elm St', 'San Francisco', 'CA', '94101'),
  (3, 'George', 'Washington', 'george@example.com', '789 Oak St', 'San Jose', 'CA', '95123'),
  (4, 'Grace', 'Kelly', 'grace@example.com', '321 Pine St', 'Los Angeles', 'CA', '90001'),
  (5, 'Gabriel', 'Garcia', 'gabriel@example.com', '987 Maple St', 'San Jose', 'CA', '95123');


-- 3. Select only the ‘first_name’ & ‘last_name’ columns from the customer table

SELECT first_name, last_name
FROM customers;

-- 4. Select those records where ‘first_name’ starts with “G” and city is ‘San Jose’

SELECT * 
FROM customers
WHERE first_name like 'G%' AND city = 'San Jose';